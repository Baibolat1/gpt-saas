# Nebula — Dark Premium SaaS Workspace

A functional FastAPI + PostgreSQL SaaS starter with account registration, JWT authentication, private project CRUD, dashboard metrics, responsive dark-premium frontend, Docker Compose, and tests.

## Features

- Email/password registration and login; passwords are hashed with bcrypt.
- Signed JWT bearer tokens and protected API endpoints.
- Project creation, listing, detail, editing, and deletion.
- User-scoped project access (users cannot read or modify another user's projects).
- Dashboard counts for total, active, and completed projects.
- Responsive frontend with search, status filtering, dialogs, toast feedback, and sign out.
- PostgreSQL via async SQLAlchemy.
- Health endpoint and basic security/unit tests.

## Run with Docker (recommended)

Requirements: Docker Desktop or Docker Engine with Compose.

```bash
cp .env.example .env
# Edit .env and set a long random SECRET_KEY before exposing this service.
docker compose up --build
```

Open http://localhost:8000. API docs: http://localhost:8000/docs.

The default Compose database credentials are for local development only. Change them before deployment.

## Run locally

Requirements: Python 3.11+ and a running PostgreSQL instance.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
# Set DATABASE_URL to your PostgreSQL connection and set SECRET_KEY.
uvicorn app.main:app --reload
```

## Test

```bash
pytest -q
```

Tests that import the app need a reachable database when the app lifespan initializes; run the test suite with PostgreSQL available and `DATABASE_URL` configured.

## API

| Method | Endpoint | Auth | Purpose |
|---|---|---:|---|
| GET | `/health` | No | Health check |
| POST | `/api/auth/register` | No | Create account and return token |
| POST | `/api/auth/login` | No | Login and return token |
| GET | `/api/auth/me` | Yes | Current account |
| GET | `/api/dashboard` | Yes | Dashboard metrics and recent projects |
| GET | `/api/projects` | Yes | List your projects |
| POST | `/api/projects` | Yes | Create project |
| GET | `/api/projects/{id}` | Yes | Read a project |
| PATCH | `/api/projects/{id}` | Yes | Update project |
| DELETE | `/api/projects/{id}` | Yes | Delete project |

Authenticated requests use `Authorization: Bearer <access_token>`.

## Production hardening checklist

- Replace `SECRET_KEY` with a high-entropy secret from a secret manager.
- Configure TLS and trusted proxy settings at the edge.
- Add rate limiting for authentication endpoints and email verification/password reset flows.
- Use Alembic migrations rather than `create_all` for schema evolution.
- Configure backups, observability, and a managed PostgreSQL service.
- Add CSRF protections if switching from bearer tokens to cookies; apply a suitable CSP and self-host or pin frontend assets.
- Add subscription/billing integration only when requirements and provider credentials are available.

## Project layout

```text
app/
  core/       config, database, security
  models/     User and Project ORM models
  routers/    auth, dashboard, projects, health
  schemas/    request/response validation
  static/     HTML, CSS, browser JavaScript
  main.py
tests/
  test_health.py
  test_security.py
Dockerfile
docker-compose.yml
requirements.txt
.env.example
```
