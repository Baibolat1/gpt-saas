from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Nebula"
    database_url: str = "postgresql+asyncpg://nebula:nebula@localhost:5432/nebula"
    secret_key: str = "change-this-secret-before-production"
    access_token_minutes: int = 60 * 24
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
