from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.dependencies import current_user
from app.models.user import User
from app.models.project import Project

router = APIRouter()

@router.get("/dashboard")
async def dashboard(user: User = Depends(current_user), db: AsyncSession = Depends(get_db)):
    total = await db.scalar(select(func.count(Project.id)).where(Project.owner_id == user.id)) or 0
    active = await db.scalar(select(func.count(Project.id)).where(Project.owner_id == user.id, Project.status == "Active")) or 0
    completed = await db.scalar(select(func.count(Project.id)).where(Project.owner_id == user.id, Project.status == "Completed")) or 0
    recent = (await db.scalars(select(Project).where(Project.owner_id == user.id).order_by(Project.created_at.desc()).limit(5))).all()
    return {
        "stats": {"total_projects": total, "active_projects": active, "completed_projects": completed},
        "recent_projects": [{"id": p.id, "name": p.name, "status": p.status, "created_at": p.created_at.isoformat()} for p in recent],
    }
