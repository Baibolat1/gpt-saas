from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=3000)
    status: str = Field(default="Active", pattern="^(Active|Paused|Completed)$")

class ProjectUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=120)
    description: str | None = Field(default=None, max_length=3000)
    status: str | None = Field(default=None, pattern="^(Active|Paused|Completed)$")

class ProjectOut(BaseModel):
    id: int
    name: str
    description: str
    status: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
