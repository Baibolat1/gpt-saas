const API = '/api';
const state = { token: localStorage.getItem('nebula_token'), user: null, projects: [], authMode: 'login' };
const $ = (id) => document.getElementById(id);
const headers = () => ({'Content-Type':'application/json', ...(state.token ? {Authorization:`Bearer ${state.token}`} : {})});
async function request(path, options={}) {
  const response = await fetch(`${API}${path}`, {...options, headers:{...headers(), ...(options.headers||{})}});
  if (response.status === 204) return null;
  const data = await response.json().catch(()=>({detail:'Unexpected server response'}));
  if (!response.ok) throw new Error(data.detail || 'Request failed');
  return data;
}
function showToast(message){const el=$('toast');el.textContent=message;el.classList.remove('hidden');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.add('hidden'),3200);}
function openModal(id){$(id).classList.remove('hidden');document.body.style.overflow='hidden';}
function closeModal(id){$(id).classList.add('hidden');document.body.style.overflow='';}
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>{closeModal('authModal');closeModal('projectModal')}));
document.querySelectorAll('.modal-backdrop').forEach(b=>b.addEventListener('click',e=>{if(e.target===b)closeModal(b.id)}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal('authModal');closeModal('projectModal')}});

function setAuthMode(mode){
  state.authMode=mode;
  document.querySelectorAll('.auth-tab').forEach(b=>b.classList.toggle('selected',b.dataset.mode===mode));
  $('nameWrap').classList.toggle('hidden',mode!=='register');
  $('authTitle').textContent=mode==='login'?'Welcome back':'Create your workspace';
  $('authSubmit').innerHTML=mode==='login'?'Sign in <span>→</span>':'Create account <span>→</span>';
  $('passwordInput').autocomplete=mode==='login'?'current-password':'new-password';
  $('authError').classList.add('hidden');
}
document.querySelectorAll('.auth-tab').forEach(b=>b.addEventListener('click',()=>setAuthMode(b.dataset.mode)));
$('openAuthBtn').addEventListener('click',()=>openModal('authModal'));
$('logoutBtn').addEventListener('click',()=>{state.token=null;state.user=null;localStorage.removeItem('nebula_token');renderSignedOut();showToast('Signed out successfully')});
$('authForm').addEventListener('submit',async e=>{
  e.preventDefault();const error=$('authError');error.classList.add('hidden');
  const payload={email:$('emailInput').value.trim(),password:$('passwordInput').value};
  if(state.authMode==='register')payload.name=$('nameInput').value.trim();
  const button=$('authSubmit');button.disabled=true;button.textContent='Please wait…';
  try{const result=await request(`/auth/${state.authMode}`,{method:'POST',body:JSON.stringify(payload)});state.token=result.access_token;state.user=result.user;localStorage.setItem('nebula_token',state.token);closeModal('authModal');$('authForm').reset();await loadWorkspace();showToast(state.authMode==='login'?'Welcome back!':'Workspace account created');}
  catch(err){error.textContent=err.message;error.classList.remove('hidden')}
  finally{button.disabled=false;setAuthMode(state.authMode)}
});
$('newProjectBtn').addEventListener('click',()=>{if(!state.token){setAuthMode('register');openModal('authModal');return}$('projectForm').reset();$('projectError').classList.add('hidden');openModal('projectModal');setTimeout(()=>$('projectName').focus(),100)});
$('projectForm').addEventListener('submit',async e=>{
  e.preventDefault();const error=$('projectError');error.classList.add('hidden');
  try{await request('/projects',{method:'POST',body:JSON.stringify({name:$('projectName').value.trim(),description:$('projectDescription').value.trim(),status:$('projectStatus').value})});closeModal('projectModal');await loadWorkspace();showToast('Project created successfully');}
  catch(err){error.textContent=err.message;error.classList.remove('hidden')}
});
$('searchInput').addEventListener('input',renderProjects);
$('statusFilter').addEventListener('change',renderProjects);
$('upgradeBtn').addEventListener('click',()=>showToast('Plans are managed by your workspace administrator.'));
$('focusBtn').addEventListener('click',()=>showToast('Take a slow breath. You have time to do good work.'));
function renderSignedOut(){
  $('profileName').textContent='Guest user';$('profileEmail').textContent='Sign in to sync';$('avatar').textContent='G';$('topAvatar').textContent='G';$('logoutBtn').classList.add('hidden');$('authNotice').classList.remove('hidden');
  $('totalStat').textContent='—';$('activeStat').textContent='—';$('completedStat').textContent='—';state.projects=[];renderProjects();
}
function renderSignedIn(){
  const name=state.user?.name||'Your workspace';$('profileName').textContent=name;$('profileEmail').textContent=state.user?.email||'';$('avatar').textContent=name.charAt(0).toUpperCase();$('topAvatar').textContent=name.charAt(0).toUpperCase();$('logoutBtn').classList.remove('hidden');$('authNotice').classList.add('hidden');
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderProjects(){
  const query=$('searchInput').value.trim().toLowerCase(),filter=$('statusFilter').value;
  const list=state.projects.filter(p=>(p.name+' '+p.description).toLowerCase().includes(query)&&(filter==='All'||p.status===filter));
  const root=$('projectsList');
  if(!state.token){root.innerHTML='<div class="empty-state"><div class="empty-orb">◫</div><b>Your next big thing starts here</b><p>Sign in and create a project to see it appear here.</p></div>';return}
  if(!list.length){root.innerHTML=`<div class="empty-state"><div class="empty-orb">⌕</div><b>${query||filter!=='All'?'No matching projects':'A clean slate'}</b><p>${query||filter!=='All'?'Try changing your search or filter.':'Create a project to get your workspace moving.'}</p></div>`;return}
  root.innerHTML=list.map(p=>`<div class="project-row"><div class="project-name"><span class="project-symbol">◫</span><div><b>${esc(p.name)}</b><small>${esc(p.description||'No description added')}</small></div></div><span class="status-badge status-${p.status.toLowerCase()}">${esc(p.status)}</span><time class="project-date">${new Date(p.created_at).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}</time><button class="row-menu" data-delete="${p.id}" title="Delete project" aria-label="Delete ${esc(p.name)}">···</button></div>`).join('');
  root.querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',async()=>{const p=state.projects.find(x=>x.id===Number(b.dataset.delete));if(!p)return;if(!confirm(`Delete “${p.name}”? This cannot be undone.`))return;try{await request(`/projects/${p.id}`,{method:'DELETE'});await loadWorkspace();showToast('Project deleted')}catch(e){showToast(e.message)}}));
}
async function loadWorkspace(){
  try{const [me,dash,projects]=await Promise.all([request('/auth/me'),request('/dashboard'),request('/projects')]);state.user=me;state.projects=projects;renderSignedIn();$('totalStat').textContent=dash.stats.total_projects;$('activeStat').textContent=dash.stats.active_projects;$('completedStat').textContent=dash.stats.completed_projects;renderProjects();}
  catch(e){state.token=null;localStorage.removeItem('nebula_token');renderSignedOut();if(e.message!=='Failed to fetch')showToast('Session expired. Please sign in again.');}
}
if(state.token)loadWorkspace();else renderSignedOut();
